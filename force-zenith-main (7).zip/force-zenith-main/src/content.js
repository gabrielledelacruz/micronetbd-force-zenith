chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        console.log(sender.tab ?
            "from a content script:" + sender.tab.url :
            "from the extension");
        if (request.greeting == "hello") {
            var con = document.getElementById("forceextension").style.display;
            if (con === "none") {
                document.getElementById("forceextension").style.display = "block"
            } else {
                document.getElementById("forceextension").style.display = "none"
            }
        }

        sendResponse({ farewell: "goodbye" });
    }
);
var substack = document.createElement("iframe");
substack.src = chrome.runtime.getURL("src/index.html");
substack.style.width = "620px";
substack.id = "forceextension";
substack.style.height = "100vh";
substack.style['z-index'] = "9000";
substack.style.position = "absolute";
substack.style.border = "none";
substack.style.display = "none";
substack.style.right = 0;
document.body.before(substack);
function createDataUrlFromHtml(htmlString) {
    // Encode the HTML string as a URI component
    const encodedHtml = encodeURIComponent(htmlString);

    // Create the data URL
    const dataUrl = encodedHtml;
    // const dataUrl = `data:text/html;charset=UTF-8,${encodedHtml}`;

    return dataUrl;
}
if (window.location.host === 'mail.google.com') {
    navigation.addEventListener("navigate", e => {
        if (e.destination.url.length > 40) {
            setTimeout(() => {
                var title = document.querySelector('[data-thread-perm-id]').innerHTML;
                if (document.querySelector("div.adf.ads")) {
                    document.querySelector("div.adf.ads").click()
                }
                var emailBodies = []
                if (document.getElementById("openinzenth")) {
                    document.getElementById("openinzenth").remove()
                }
                document.querySelector('[data-thread-perm-id]').innerHTML += `<a id="openinzenth" style="cursor: pointer;display: inline;padding: 10px;" ><img src="${chrome.runtime.getURL("/logo/logo_32x32.png")}" style="vertical-align: bottom;width: 30px;" alt="" srcset=""></a>`
                console.log(`navigate ->`, e.destination.url, e.destination.url.length, "email opened", title);
                // const indiElements = document.querySelectorAll('.indi');
                // for (let i = 0; i < indiElements.length; i++) {
                //     indiElements[i].remove();
                // }
                // document.querySelectorAll("div[id^=':'] [data-message-id] span.qu").forEach((x, i) => {
                //     console.log("emails > ", x);
                //     x.parentNode.innerHTML += `<a id=emailbody-${i} class="indi" style="cursor: pointer;display: inline;padding: 10px;" ><img src="${chrome.runtime.getURL("/logo/logo_32x32.png")}" style="vertical-align: bottom;width: 30px;" alt="" srcset=""></a>`;
                // })
                // document.querySelectorAll("div[id^=':'] [data-message-id]").forEach(x => {
                //     emailBodies.push(x.querySelectorAll("table")[3])
                // })
                // // [0].querySelectorAll("table")
                // console.log('emailBodies', emailBodies);
                // const emailBodiesArray = document.querySelectorAll("[id*='emailBodies-']");
                // for (let i = 0; i < emailBodiesArray.length; i++) {
                //     emailBodiesArray[i].addEventListener('click', function () {
                //         let table = emailBodiesArray[i].id.split('-');
                //         console.log(emailBodies[table[1]]);
                //     });
                // }
                const el = document.getElementById("openinzenth");

                el.addEventListener(
                    "click",
                    () => {

                        const htmlString = document.querySelectorAll("table.Bs.nH.iY.bAt")[0].outerHTML;

                        // Create a temporary element to parse the HTML string
                        const tempElement = document.createElement('div');
                        tempElement.innerHTML = htmlString;

                        // Select all elements with the data-saferedirecturl attribute
                        const elements = tempElement.querySelectorAll('[data-saferedirecturl]');
                        const elementsclass = tempElement.querySelectorAll('[class]');
                        // const elementsanchor = tempElement.querySelectorAll('a');
                        // const elementsimg = tempElement.querySelectorAll('img');
                        // const elementsback = tempElement.querySelectorAll('[background]');

                        tempElement.querySelector("div.nH.V8djrc.byY").remove();
                        tempElement.querySelectorAll("div.gE.iv.gt").forEach(x => {
                            x.remove();
                        })
                        tempElement.querySelectorAll("div.gA.gt.acV").forEach(x => {
                            x.remove();
                        })
                        tempElement.querySelectorAll("div.aju").forEach(x => {
                            x.remove();
                        })
                        tempElement.querySelectorAll("div.kv").forEach(x => {
                            x.remove();
                        })
                        if (tempElement.querySelector("div.hq.gt")) {
                            tempElement.querySelector("div.hq.gt").remove();
                        }
                        if (tempElement.querySelector("div.gmail_attr")) {
                            tempElement.querySelector("div.gmail_attr").remove();
                        }

                        const nodeList = tempElement.querySelectorAll("div.h7");
                        console.log("nodeList", nodeList)
                        // loop through the NodeList starting from the second element
                        for (let i = 1; i < nodeList.length; i++) {
                            // remove the current element from its parent node
                            nodeList[i].parentNode.removeChild(nodeList[i]);
                        }
                        // if(tempElement.querySelector("gA gt acV")){
                        // }aju
                        // const elementsWithClass = tempElement.querySelectorAll('[class]');gA gt acV
                        // for (let i = 0; i < elementsWithClass.length; i++) {
                        //     elementsWithClass[i].parentNode.removeChild(elementsWithClass[i]);
                        // }
                        // Loop through each element and remove the attribute
                        elements.forEach(element => {
                            element.removeAttribute('data-saferedirecturl');
                        });
                        // const elementsWithClass = tempElement.querySelectorAll('[class]');
                        // elementsWithClass.forEach(element => {
                        //     const styles = window.getComputedStyle(element);
                        //     element.classList.forEach(className => {
                        //         const value = styles.getPropertyValue(`.${className}`);
                        //         element.style.cssText += `${value};`;
                        //     });
                        //     element.removeAttribute('class');
                        // });
                        elementsclass.forEach(element => {
                            // element.removeAttribute('class');

                            // element.parentNode.removeChild(element);
                        });
                        // elementsanchor.forEach(element => {
                        //     element.parentNode.removeChild(element);
                        // });
                        // elementsimg.forEach(element => {
                        //     element.parentNode.removeChild(element);
                        // });
                        // elementsback.forEach(element => {
                        //     element.parentNode.removeChild(element);
                        // });

                        var title = `<h2 id=title style="text-align: center;">Email Subject : ${document.title.split("-")[0]}</h2>`;
                        // Get the modified HTML string
                        const modifiedHtmlString = title + tempElement.innerHTML;
                        // console.log(encodeURIComponent(document.querySelectorAll("table")[10].outerHTML),modifiedHtmlString)
                        top.document.getElementById('forceextension').setAttribute("src", chrome.runtime.getURL("src/createTask.html") + '?emailTitle=' + document.title + '&emailLink=' + createDataUrlFromHtml(modifiedHtmlString));
                        // top.document.getElementById('forceextension').setAttribute("src", chrome.runtime.getURL("src/createTask.html") + '?emailLink=' + createDataUrlFromHtml(document.querySelectorAll("table")[10].outerHTML));
                        // top.document.getElementById('forceextension').setAttribute("src", chrome.runtime.getURL("src/createTask.html") + '?emailLink=' + window.location.href.substr(39));
                        document.getElementById("forceextension").style.display = "block";
                    },
                    false
                );
            }, 1000);
            // setTimeout(() => {
            //     top.document.getElementById('forceextension').setAttribute("src", chrome.runtime.getURL("src/index.html"));
            // }, 3000);
        }
    });
}

function openEmail(link) {
    window.open(link, "_self")
}
