
if (getCookie("login") == null) window.location = "./index.html";
function htmlToDataUrl(htmlString) {
  // const encodedHtml = encodeURIComponent(htmlString);
  // const dataUrl = `data:text/html;charset=utf-8,${encodedHtml}`;
  return `data:text/html;charset=utf-8,${htmlString}`;
}
function openwindow(html) {
  const tempElement = document.createElement('div');
  tempElement.innerHTML = html;
  var title=tempElement.querySelector('#title').innerHTML;

  const win = window.open("");
  win.document.write(
    `<html><head><title>${title}</title></head><body style="text-align: -webkit-center;overflow-x:hidden">${html}</body></html>`
  );
  win.document.close();
}
document.querySelector("#lookupOwner").value = "Current User";
document.querySelector("#lookupOwner").setAttribute('data-info', getCookie("login"));
var tasktypes = localStorage.getItem('default_task_types')
tasktypes = tasktypes.split(',');
tasktypes.forEach(el => {
  document.getElementById("tasktypes").innerHTML += `
  <option value="${el}">${el}</option>
  `
});
var taskstatus = localStorage.getItem('default_task_status')
taskstatus = taskstatus.split(',');
taskstatus.forEach(el => {
  document.getElementById("taskstatus").innerHTML += `
  <option value="${el}">${el}</option>
  `
});
document.getElementById("taskstatus").onchange = (e) => {
  const value = e.target.value;
  if (value == "Completed") {
    document.getElementById("enddatestatus").style.display = "flex"
  } else {
    document.getElementById("enddatestatus").style.display = "none"
  }
}
if (localStorage.getItem('createTaskForm')) {

  const params = JSON.parse(localStorage.getItem('createTaskForm'));
  var form = document.querySelector('form')
  console.log('createTaskForm', params, form);
  let sd = new Date(params.start_date);
  form["start_date"].value = sd.toISOString().substr(0, 10);
  form["start_time"].value = params.start_date.substr(11);
  if (params.end_date) {

    let ed = new Date(params.end_date);
    if (ed !== "Invalid Date" && params.end_date !== "") {
      form["end_date"].value = ed.toISOString().substr(0, 10);
      form["end_time"].value = params.end_date.substr(11);
    }
    if (params.end_date === "") {
      form["end_date"].value = ''
      form["end_time"].value = ''
    }
  }
  form.name.value = params.name;
  // form["owner"].value = params.owner;
  form["status"].value = params.status;
  form["notes"].value = params.notes;

  if (params.task_id) {
    form["hours"].value = params.hours;
    form["minutes"].value = params.minutes;
  }
  document.getElementById("taskstatus").value = params.status;
  // document.querySelector("#lookupOwner").setAttribute('data-info', params.user_id);
}
const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);

function paramsToObject(entries) {
  const result = {}
  for (const [key, value] of entries) {
    result[key] = value;
  }
  return result;
}
const entries = urlParams.entries();
const params = paramsToObject(entries);
console.log('params', params);

setTimeout(() => {
  // if(window.location.host === 'mail.google.com'){
  if (params.emailLink) {
    var form = document.querySelector('form')
    const tempElement = document.createElement('div');
    tempElement.innerHTML = params.emailLink;
    var title=tempElement.querySelector('#title').innerHTML;
    title=title.replace("Email Subject :", "");
    form["notes"].value = title
    form["name"].value = title
    // document.getElementById("emailLink").href = `data:text/html;charset=UTF-8;page=21,${encodeURIComponent(params.emailLink)}`
    // document.getElementById("emailLink").href = 'https://mail.google.com/mail/u/0/#inbox' + params.emailLink
    document.getElementById("emailLink").innerHTML = '( Email Linked )'
    document.getElementById("emailLink").addEventListener("click", () => {
    // console.log('openwindow',title)
 
      openwindow(params.emailLink)
    });
  }
  // }
}, 1000);
// this.Tracker.toggleTask(i, this.getFromid(i).hours, this.getFromid(i).minutes);
//         chrome.runtime.sendMessage({ name: 'startTracking', data: this.getFromid(i) ,auth: this.owner, timestamp: this.Tracker.getTime(i) });
document.forms.createTaskForm.addEventListener('change', (event) => {
  var formEl = document.forms.createTaskForm;
  const formData = new FormData(formEl);
  const formProps = Object.fromEntries(formData);
  formProps.project_id = document.querySelector("#lookupProject").getAttribute('data-info')
  formProps.owner = document.querySelector("#lookupOwner").getAttribute('data-info')
  formProps.minutes = parseInt(formProps.minutes);
  formProps.hours = parseInt(formProps.hours);
  formProps.start_date = formProps.start_date + " " + formProps.start_time + ":00";
  formProps.end_date = formProps.end_date + " " + formProps.end_time + ":00";
  if (formProps.status !== "Completed") {
    delete formProps.end_date;
  }
  if (formProps.project_id === null) {
    delete formProps.project_id;
  }
  if (params.emailLink) {
    formProps.email_link = params.emailLink;
    // formProps.email_link = 'https://mail.google.com/mail/u/0/#inbox' + params.emailLink;
  }
  // console.log("form values changed", formProps ,window.localStorage);
  localStorage.setItem('createTaskForm', JSON.stringify(formProps));
})
document.forms.createTaskForm.addEventListener('submit', (event) => {
  event.preventDefault();
  var formEl = document.forms.createTaskForm;
  const formData = new FormData(formEl);
  const formProps = Object.fromEntries(formData);
  formProps.project_id = document.querySelector("#lookupProject").getAttribute('data-info')
  formProps.owner = document.querySelector("#lookupOwner").getAttribute('data-info')
  formProps.minutes = parseInt(formProps.minutes);
  formProps.hours = parseInt(formProps.hours);
  formProps.start_date = formProps.start_date + " " + formProps.start_time + ":00";
  formProps.end_date = formProps.end_date + " " + formProps.end_time + ":00";

  if (formProps.status !== "Completed") {
    delete formProps.end_date;
  }
  if (params.emailLink) {
    formProps.email_link = params.emailLink;
  }
  const requiredFields = formEl.querySelectorAll('[required]');
  let allFieldsValid = true;
  requiredFields.forEach(function (field) {
    if (!field.checkValidity()) {
      allFieldsValid = false;
    }
  });
  if (allFieldsValid) {
    createTask(formProps).then((x) => {
      localStorage.removeItem('createTaskForm');
      console.log("createTask", formProps)
      if (formProps.status == "In Progress") {
        console.log('i ran ', x)
        if (!formProps.task_id) {
          formProps.task_id = x.task_id;
        }

        chrome.runtime.sendMessage({ name: 'startTracking', data: formProps, auth: getCookie("login") });
      }
      window.location = './home.html';
    })
  }
})
console.log(new Date(), new Date().toISOString().substring(0, 10), new Date().toISOString())
function getTime() {
  return ('0' + new Date().getHours()).substr(-2) + ":" + ('0' + new Date().getMinutes()).substr(-2);
}
document.getElementById("start_date").valueAsDate = new Date();
document.getElementById("start_time").value = getTime();
// document.getElementById("start_date").value = new Date().toISOString().substring(0, 10);
// document.getElementById("start_time").value = new Date().toISOString().substr(11, 5);

const delay = 500;
let otimerId;
document.getElementById("lookupOwner").onkeyup = (e) => {
  clearTimeout(otimerId);
  otimerId = setTimeout(() => {
    const value = e.target.value;
    if (value === '') return document.getElementById("lookupOwnerList").style.display = "none";
    search('user?search_string=' + value).then(x => {
      document.getElementById("lookupOwnerList").style.display = "block";
      document.getElementById("OwnersList").innerHTML = "";
      x.users.forEach(el => {
        document.getElementById("OwnersList").innerHTML += `
                <li role="picker" class="slds-listbox__item" data-info="${el.user_id}">
                <div class="slds-media slds-listbox__option slds-listbox__option_entity slds-listbox__option_has-meta" role="option">
                  <span class="slds-media__body">
                    <span class="slds-listbox__option-text slds-listbox__option-text_entity">
                      <span><mark>${el.user_name}</mark></span>
                    </span>
                  </span>
                </div>
              </li>
                `;
      });
      document.querySelectorAll('[role="picker"]').forEach((x) => {
        x.addEventListener('click', () => {
          e.target.value = x.innerText;
          document.querySelector("#lookupOwner").setAttribute('data-info', x.getAttribute('data-info'));
          document.getElementById("lookupOwnerList").style.display = "none";
        })
      })
    })
  }, delay)

}

let ptimerId;
document.getElementById("lookupProject").onkeyup = (e) => {
  clearTimeout(ptimerId);
  ptimerId = setTimeout(() => {
    const value = e.target.value;

    if (value === '') return document.getElementById("lookupProjectList").style.display = "none";

    search('project?search_string=' + value).then(x => {
      document.getElementById("lookupProjectList").style.display = "block";
      document.getElementById("ProjectList").innerHTML = "";
      x.users.forEach(el => {
        document.getElementById("ProjectList").innerHTML += `
                <li role="picker" class="slds-listbox__item" data-info="${el.project_id}">
                <div class="slds-media slds-listbox__option slds-listbox__option_entity slds-listbox__option_has-meta" role="option">
                  <span class="slds-media__body">
                    <span class="slds-listbox__option-text slds-listbox__option-text_entity">
                      <span><mark>${el.project_name}</mark></span>
                    </span>
                  </span>
                </div>
              </li>
                `;
      });
      document.querySelectorAll('[role="picker"]').forEach((x) => {
        x.addEventListener('click', () => {
          e.target.value = x.innerText;
          document.querySelector("#lookupProject").setAttribute('data-info', x.getAttribute('data-info'));
          document.getElementById("lookupProjectList").style.display = "none";
        })
      })
    })

  }, delay)

}




